sudo sed -i '/home\/wvtohls/d' /etc/fstab
sleep 2
sudo mount -av